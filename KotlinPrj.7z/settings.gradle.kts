
rootProject.name = "KotlinTest"

