package models

data class Artist(
    val ConstituentID: Number,
    val DisplayName: String,
    val ArtistBio: String,
    val Nationality: String,
    val Gender: String,
    val BeginDate: Number,
    val EndDate: Number,
    val Wiki_QID: String,
    val ULAN: String){

    fun display(){
        println("####################################################################################")
        println("ID          : $ConstituentID");
        println("Name        : $DisplayName");
        println("Description : $ArtistBio");
        println("Nationality : $Nationality");
        println("Gender      : $Gender");
        println("Born        : $BeginDate");
        println("Dead        : $EndDate");
        println("Wiki        : $Wiki_QID");
        println("ULAN        : $ULAN");
        println("####################################################################################\n")
    }
}
