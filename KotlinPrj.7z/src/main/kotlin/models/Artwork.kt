package models

data class Artwork(
    val Title: String,
    val Artist: List<String>,
    val ConstituentID: List<Number>,
    val ArtistBio: List<String>,
    val Nationality: List<String>,
    val BeginDate: List<Number>,
    val EndDate: List<Number>,
    val Gender: List<String>,
    val Date: String,
    val Medium: String,
    val Dimensions: String,
    val CreditLine: String,
    val AccessionNumber: String,
    val Classification: String,
    val Department: String,
    val DateAcquired: String,
    val Cataloged: String,
    val ObjectID: Number,
    val URL: String,
    val ThumbnailURL: String,
    val Height: Number,
    val Width: Number ){

    fun display(){
        println("####################################################################################")
        println("Title                 : $Title");
        println("Artist Name           : ${Artist[0]}");
        println("Artist ID             : ${ConstituentID[0]}");
        println("Artist Bio            : ${ArtistBio[0]}");
        println("Artist Nationality    : ${Nationality[0]}");
        println("Born in               : ${BeginDate[0]}");
        println("(Dead in)             : ${EndDate[0]}");
        println("Gender                : ${Gender[0]}");
        println("Date                  : $Date");
        println("Medium                : $Medium");
        println("Dimensions            : $Dimensions");
        println("CreditLine            : $CreditLine");
        println("AccessionNumber       : $AccessionNumber");
        println("Classification        : $Classification");
        println("Department            : $Department");
        println("DateAcquired          : $DateAcquired");
        println("Cataloged             : $Cataloged");
        println("ID                    : $ObjectID");
        println("URL                   : $URL");
        println("ThumbnailURL          : $ThumbnailURL");
        println("Height (cm)           : $Height");
        println("Width  (cm)           : $Width");
        println("####################################################################################\n")
    }
}
