package utils

const val BASE_URL = "http://localhost:5984"
const val ARTISTS_DB = "artists"
const val ARTWORKS_DB = "artworks"
const val EXIT_CHAR = "E"
const val SEARCH_CHAR = "GO"