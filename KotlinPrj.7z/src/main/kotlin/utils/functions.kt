package utils

import com.cloudant.client.api.query.Expression
import com.cloudant.client.api.query.Operation
import com.cloudant.client.api.query.Selector

/**
 * Clear the console.
 *
 * This function simply print 100 lines in the console to fake the clear.
 */
fun clear(){
    var lines:String = ""
    for(i in 1..100) lines+="\n"
    print(lines)
}

/**
 * Generate a list based on param list with indexes in value.
 *
 * example : ["hello", "Good", "Morning"] -->  like ["0", "1", "2"]
 *
 * @param v list of String.
 * @return ret contains the new list of String.
 */
fun listGeneration(v:List<String>):List<String>{
    var ret:List<String> = listOf()
    for(i in v.indices) ret += (i.toString())
    return ret
}

/**
 * Tranforms a string to a case insensitive REGEX.
 *
 * example : hello --> (H|h)(E|e)(L|l)(L|l)(O|o)
 *
 * @param strIn string to modify.
 * @return strOut contains the modified string.
 */
fun insensitiveStringRegex(strIn:String):String{
    var strOut:String = ""
    for (c in strIn){
        strOut += "("+c.uppercase()+"|"+c.lowercase()+")"
    }
    return strOut
}

/**
 * Generate a selector based on multiple selectors.
 *
 * @param fields list of String containing the name of the filter fields.
 * @param values list of String containing the values of the filter fields.
 * @return select contains concatenation of 'and' criterias.
 */
fun generateSelector(fields:List<String>, values:List<String>): Selector?{

    var select: Selector? = null
    var first:Boolean = true
    for (i in fields.indices) {
        if (!values[i].isNullOrBlank()){
            if (first){
                select = Expression.regex(fields[i], ".*"+insensitiveStringRegex(values[i])+".*")
                first = false
            }
            else {
                select =
                    Operation.and(select, Expression.regex(fields[i], ".*" + insensitiveStringRegex(values[i]) + ".*"))
            }
        }
    }
    return select
}