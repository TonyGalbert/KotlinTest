import models.Artist
import models.Artwork
import utils.*
import java.net.URL
import com.cloudant.client.api.ClientBuilder
import com.cloudant.client.api.Database
import com.cloudant.client.api.query.Expression
import com.cloudant.client.api.query.QueryBuilder
import com.cloudant.client.api.query.QueryResult

fun main() {

    // Definition of variables
    val databases:List<String> = listOf("ARTISTS", "ARTWORKS")
    val artistFields:List<String> = listOf("ConstituentID", "DisplayName", "ArtistBio", "Nationality", "Gender",
        "BeginDate", "EndDate", "Wiki QID", "ULAN")
    val artistValues: MutableList<String> = List(artistFields.size){""}.toMutableList()
    val artworkFields:List<String> = listOf("Title", "Artist", "ConstituentID", "ArtistBio", "Nationality", "BeginDate",
        "EndDate", "Gender", "Date", "Medium", "Dimensions", "CreditLine",
        "AccessionNumber", "Classification", "Department",
        "DateAcquired", "Cataloged", "ObjectID", "URL", "ThumbnailURL", "Height", "Width")
    val artworkValues: MutableList<String> = List(artworkFields.size){""}.toMutableList()

    // Start the loop asking which database to use (artists or artworks)
    var userChoice:String?
    do {
        clear()
        println("      **************************************************************")
        println("      **               Welcome in this Search tool !              **")
        println("      **************************************************************\n\n")

        println("In which database do you want to execute the research ? \n")

        for (i in databases.indices) {
            println("  $i - ${databases[i]}")
        }

        println("\nIn which database do you want to execute the research ? (Type the number or Type '$EXIT_CHAR' to Exit)")
        print("Answer : ")
        userChoice = readLine()
    } while (!userChoice?.uppercase().equals(EXIT_CHAR)
            and !listGeneration(databases).contains(userChoice))

    when(userChoice){
        EXIT_CHAR.uppercase(),EXIT_CHAR.lowercase() -> return
        "0" -> artistsChoice(artistFields, artistValues)
        "1" -> artworksChoice(artworkFields, artworkValues)
    }

}

// In case of the user chose Artist DB, we show the filters
// Then, it is possible to populate the filters and execute the research
// At the end, the user will nbe able to display complete information about the artist by giving the ID
fun artistsChoice(artistFields:List<String>, artistValues:MutableList<String>){

    val client = ClientBuilder.url(URL(BASE_URL)).build()
    val artists:Database

    var userChoice:String?

    do {
        clear()
        println("      **************************************************************")
        println("      **                         ARTISTS                          **")
        println("      **************************************************************\n\n")
        println("Available filters : \n")

        for (i in artistFields.indices) {
            println("  $i - ${artistFields[i]} : ${artistValues[i]}")
        }

        println("\nWhich filter do you want to update ? (Type '$EXIT_CHAR' to Exit or '$SEARCH_CHAR' to Search)")
        print("Answer : ")
        userChoice = readLine()
    } while (!userChoice?.uppercase().equals(SEARCH_CHAR)
        and !userChoice?.uppercase().equals(EXIT_CHAR)
        and !listGeneration(artistFields).contains(userChoice))

    if (userChoice?.uppercase() == EXIT_CHAR) return
    if (userChoice?.uppercase() == SEARCH_CHAR){
        val start = System.currentTimeMillis()
        println("Work in progress...")
        artists = client.database(ARTISTS_DB, false)

        val queryResult: QueryResult<Artist> =
            artists.query(QueryBuilder(generateSelector(artistFields, artistValues)).build(), Artist::class.java)
        val duration = (System.currentTimeMillis() - start)/1000.0

        var artistFound: Artist? = null
        do {
            clear()
            println("\nQuery result: \n")
            queryResult.docs.forEach { artist -> println(" * ${artist.DisplayName} (${artist.ConstituentID})") }
            println("\n*** ${queryResult.docs.size} result(s) found (in " + duration + " s) ***\n")

            artistFound?.display()

            println("Do you want to display more information ? (If no, press '$EXIT_CHAR' to Exit)")
            print("Type the ID number : ")
            val number:String? = readLine()
            if (number?.toIntOrNull() != null ){
                artistFound= artists.find(Artist::class.java, number)
            }
        }
        while(number?.uppercase() != EXIT_CHAR)
    }
    else {
        clear()
        val index = userChoice!!.toInt()
        println(artistFields[index] + " : ")
        artistValues[index] = readLine().toString()
        artistsChoice(artistFields, artistValues)
    }

    println("Bye !!")
}

fun artworksChoice(artworkFields:List<String>, artworkValues:MutableList<String>){

    val client = ClientBuilder.url(URL(BASE_URL)).build()
    val artworks:Database

    var userChoice:String?

    do {
        clear()
        println("      **************************************************************")
        println("      **                         ARTWORKS                         **")
        println("      **************************************************************\n\n")
        println("Available filters : \n")

        for (i in artworkFields.indices) {
            println("  $i - ${artworkFields[i]} : ${artworkValues[i]}")
        }

        println("\nWhich filter do you want to update ? (Type '$EXIT_CHAR' to Exit or '$SEARCH_CHAR' to Search)")
        print("Answer : ")
        userChoice = readLine()
    } while (!userChoice?.uppercase().equals(SEARCH_CHAR)
        and !userChoice?.uppercase().equals(EXIT_CHAR)
        and !listGeneration(artworkFields).contains(userChoice))

    if (userChoice?.uppercase() == EXIT_CHAR) return
    if (userChoice?.uppercase() == SEARCH_CHAR){
        val start = System.currentTimeMillis()
        println("Work in progress...")
        artworks = client.database(ARTWORKS_DB, false)

        val queryResult: QueryResult<Artwork>  =
            artworks.query(QueryBuilder(generateSelector(artworkFields, artworkValues)).build(), Artwork::class.java)
        val duration = (System.currentTimeMillis() - start)/1000.0

        var artworkFound: Artwork? = null
        do {
            clear()
            println("\nQuery result: \n")
            queryResult.docs.forEach { artwork -> println(" * ${artwork.Title} (${artwork.ObjectID})") }
            println("\n*** ${queryResult.docs.size} result(s) found (in " + duration + " s) ***\n")

            artworkFound?.display()

            println("Do you want to display more information ? (If no, press '$EXIT_CHAR' to Exit)")
            print("Type the ID number : ")
            val number:String? = readLine()
            if (number?.toIntOrNull() != null ){
                artworkFound= artworks.find(Artwork::class.java, number)
            }
        }
        while(number?.uppercase() != EXIT_CHAR)

    }
    else {
        clear()
        val index = userChoice!!.toInt()
        println(artworkFields[index] + " : ")
        artworkValues[index] = readLine().toString()
        artworksChoice(artworkFields, artworkValues)
    }
}
